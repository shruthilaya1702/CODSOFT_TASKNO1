"""
Data Cleaning Pipeline Demo
============================
1. Generate a realistic "messy" sample dataset (simulating a raw import)
2. Inspect its structure
3. Identify missing values, duplicates, and inconsistent entries
4. Clean everything (nulls, duplicates, dtypes, inconsistent categories)
5. Save the cleaned dataset as a new CSV
"""

import pandas as pd
import numpy as np

# ---------------------------------------------------------------------------
# STEP 0: Create a realistic messy dataset (simulating a raw CSV import)
# ---------------------------------------------------------------------------
np.random.seed(42)

raw_data = {
    "CustomerID": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 11, 12, 13, 14, 15,
                   16, 17, 18, 19, 20, 1, 21, 22, 23, 24, 25],
    "Name": ["John Smith", "jane doe", "Bob Johnson", "Alice Brown", "  Charlie Davis  ",
             "EVE WILSON", "Frank Miller", None, "Grace Lee", "Henry Ford", "Henry Ford",
             "Ivy Chen", "Jack Ryan", "Kelly Rowan", "Liam Neeson", "Mona Lisa",
             "Nate Diaz", "Olivia Pope", None, "Paul Walker", "Quinn Fabray",
             "John Smith", "Rita Ora", "Sam Winchester", "Tara West", "Uma Thurman", "Vin Diesel"],
    "Age": [28, "34", 45, None, 29, "seventeen", 52, 31, -5, 40, 40, 27, None, 33,
            150, 22, 38, 41, 26, None, 30, 28, 45, "29", 36, 44, 39],
    "Gender": ["Male", "F", "male", "Female", "M", "female", "Male", "Female", "M",
               "Male", "Male", None, "Female", "F", "Male", "female", "M", "Female",
               "male", "F", None, "Male", "female", "M", "Female", "male", "F"],
    "Email": ["john.smith@email.com", "JANE.DOE@EMAIL.COM", "bob@email", "alice.brown@email.com",
              "charlie@email.com ", None, "frank.miller@email.com", "grace@email.com",
              "henry@email.com", "henry@email.com", "henry@email.com", "ivy@email.com",
              "jack@email.com", "kelly@email.com", "liam@email.com", "mona@email.com",
              "nate@email.com", "olivia@email.com", "paul@email.com", "quinn@email.com",
              None, "john.smith@email.com", "rita@email.com", "sam@email.com",
              "tara@email.com", "uma@email.com", "vin@email.com"],
    "SignupDate": ["2023-01-15", "01/22/2023", "15-Mar-2023", "2023-04-10", "05/19/2023",
                   "2023-06-01", None, "2023-07-14", "08/09/2023", "2023-09-05",
                   "2023-09-05", "10-Nov-2023", "2023-12-01", "01/15/2024", "2024-02-20",
                   "03/10/2024", "2024-04-15", "12-May-2024", "2024-06-18", None,
                   "2024-08-01", "2023-01-15", "2024-09-09", "10/10/2024", "2024-11-11",
                   "2024-12-12", "2025-01-01"],
    "PurchaseAmount": ["$120.50", "89.99", "$45,000.00", None, "150.00", "75.5", "$200.00",
                       "99.99", "-20.00", "300.00", "300.00", "45.00", "60.00", None,
                       "1200.00", "80.00", "95.50", "110.00", "$250.00", "70.00",
                       "130.00", "120.50", "85.00", "None", "175.00", "220.00", "90.00"],
    "Country": ["USA", "usa", "U.S.A", "Canada", "CANADA ", "canada", "UK", "U.K.",
                "uk", "USA", "USA", "Germany", "germany", "GERMANY", "France", "france",
                "  France", "India", "india", "INDIA", "Canada", "USA", "UK", "Germany",
                "France", "India", "USA"],
}

df_raw = pd.DataFrame(raw_data)
df_raw.to_csv("/home/claude/raw_dataset.csv", index=False)

print("=" * 70)
print("STEP 1: IMPORT & INSPECT STRUCTURE")
print("=" * 70)
df = pd.read_csv("/home/claude/raw_dataset.csv")
print(f"\nShape: {df.shape}")
print(f"\nColumn dtypes:\n{df.dtypes}")
print(f"\nFirst 5 rows:\n{df.head()}")

print("\n" + "=" * 70)
print("STEP 2: IDENTIFY ISSUES")
print("=" * 70)

print("\n--- Missing values per column ---")
print(df.isnull().sum())

print("\n--- Duplicate rows (full exact duplicates) ---")
print(f"Exact duplicate rows: {df.duplicated().sum()}")
print(f"Duplicate CustomerIDs: {df['CustomerID'].duplicated().sum()}")

print("\n--- Inconsistent categorical entries ---")
print(f"Gender unique values: {df['Gender'].unique()}")
print(f"Country unique values: {df['Country'].unique()}")

print("\n--- Inconsistent data types ---")
print(f"Age column sample values: {df['Age'].unique()}")
print(f"PurchaseAmount column sample values: {df['PurchaseAmount'].unique()[:8]}")
print(f"SignupDate column sample values: {df['SignupDate'].unique()[:8]}")

# ---------------------------------------------------------------------------
# STEP 3: CLEAN THE DATA
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("STEP 3: CLEANING")
print("=" * 70)

df_clean = df.copy()

# 3a. Standardize column names (trim/lower not needed here, already clean, but good practice)
df_clean.columns = [c.strip() for c in df_clean.columns]

# 3b. Clean text fields: strip whitespace, fix casing
df_clean["Name"] = df_clean["Name"].str.strip().str.title()
df_clean["Email"] = df_clean["Email"].str.strip().str.lower()

# 3c. Standardize Gender into consistent categories
gender_map = {
    "male": "Male", "m": "Male",
    "female": "Female", "f": "Female",
}
df_clean["Gender"] = df_clean["Gender"].str.strip().str.lower().map(gender_map)

# 3d. Standardize Country names
country_map = {
    "usa": "USA", "u.s.a": "USA",
    "uk": "UK", "u.k.": "UK",
    "canada": "Canada", "germany": "Germany",
    "france": "France", "india": "India",
}
df_clean["Country"] = df_clean["Country"].str.strip().str.lower().map(country_map)

# 3e. Fix Age: coerce to numeric, treat impossible values (negative, >120) as missing
df_clean["Age"] = pd.to_numeric(df_clean["Age"], errors="coerce")
df_clean.loc[(df_clean["Age"] < 0) | (df_clean["Age"] > 120), "Age"] = np.nan

# 3f. Fix PurchaseAmount: strip $ and commas, coerce to numeric, treat negatives/"None" as missing
df_clean["PurchaseAmount"] = (
    df_clean["PurchaseAmount"]
    .astype(str)
    .str.replace(r"[\$,]", "", regex=True)
    .replace("None", np.nan)
)
df_clean["PurchaseAmount"] = pd.to_numeric(df_clean["PurchaseAmount"], errors="coerce")
df_clean.loc[df_clean["PurchaseAmount"] < 0, "PurchaseAmount"] = np.nan

# 3g. Fix SignupDate: parse mixed formats into a single datetime dtype
df_clean["SignupDate"] = pd.to_datetime(df_clean["SignupDate"], errors="coerce", format="mixed")

# 3h. Handle missing values
#   - Numeric columns: fill with column median
#   - Categorical columns: fill with "Unknown"
#   - Rows missing critical identifiers (Name AND Email both missing) would be dropped,
#     but here we just fill Name/Email gaps with "Unknown"/flag
df_clean["Age"] = df_clean["Age"].fillna(df_clean["Age"].median())
df_clean["PurchaseAmount"] = df_clean["PurchaseAmount"].fillna(df_clean["PurchaseAmount"].median())
df_clean["Gender"] = df_clean["Gender"].fillna("Unknown")
df_clean["Name"] = df_clean["Name"].fillna("Unknown")
df_clean["Email"] = df_clean["Email"].fillna("unknown@unknown.com")
df_clean["SignupDate"] = df_clean["SignupDate"].fillna(df_clean["SignupDate"].median())

# 3i. Remove duplicate rows
#   - First remove exact full-row duplicates
before = len(df_clean)
df_clean = df_clean.drop_duplicates()
#   - Then remove duplicate CustomerIDs, keeping the first occurrence
df_clean = df_clean.drop_duplicates(subset="CustomerID", keep="first")
after = len(df_clean)
print(f"\nRemoved {before - after} duplicate rows (exact + duplicate CustomerID)")

# 3j. Correct final data types
df_clean["CustomerID"] = df_clean["CustomerID"].astype(int)
df_clean["Age"] = df_clean["Age"].astype(int)
df_clean["PurchaseAmount"] = df_clean["PurchaseAmount"].round(2)
df_clean["Gender"] = df_clean["Gender"].astype("category")
df_clean["Country"] = df_clean["Country"].astype("category")

# 3k. Reset index
df_clean = df_clean.reset_index(drop=True)

print("\n--- Cleaned dataset info ---")
print(df_clean.info())
print("\n--- Cleaned dataset preview ---")
print(df_clean.head(10))

print("\n--- Post-clean sanity checks ---")
print(f"Remaining missing values:\n{df_clean.isnull().sum()}")
print(f"Remaining exact duplicate rows: {df_clean.duplicated().sum()}")
print(f"Gender categories: {df_clean['Gender'].unique().tolist()}")
print(f"Country categories: {df_clean['Country'].unique().tolist()}")

# ---------------------------------------------------------------------------
# STEP 4 (Bonus): Save cleaned dataset
# ---------------------------------------------------------------------------
df_clean.to_csv("/home/claude/cleaned_dataset.csv", index=False)
print("\nSaved cleaned dataset to cleaned_dataset.csv")
print(f"Final shape: {df_clean.shape}")
